import React from 'react'

const Product = () => {
  return (
    <div>
      <h1>koi dikkat nahi h yrr</h1>
    </div>
  )
}

export default Product
